<?= $this->start('content') ?>

<?= $this->includePartial('/frontend/home/components/hero-section') ?>

<?= $this->includePartial('/frontend/home/components/stats-section') ?>

<?= $this->includePartial('/frontend/home/ads/ad-afterhero') ?>

<?= $this->includePartial('/frontend/home/components/recently-added-section') ?>

<?= $this->includePartial('/frontend/home/components/now-airing-section') ?>

<?= $this->includePartial('/frontend/home/components/new-episodes-section') ?>

<?= $this->includePartial('/frontend/home/components/trending-section') ?>

<?= $this->includePartial('/frontend/home/ads/ad-midpage') ?>

<?= $this->includePartial('/frontend/home/components/schedule-section') ?>

<?= $this->includePartial('/frontend/home/components/tmdb-top10-section') ?>


<?= $this->includePartial('/frontend/home/ads/ad-footer') ?>

<?= $this->end() ?>

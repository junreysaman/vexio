<?= $this->start('content') ?>

<?php
$tabs = [
    'movies' => ['label' => 'Movies', 'icon' => 'icon-movie'],
    'tv' => ['label' => 'TV Shows', 'icon' => 'icon-live_tv'],
];
$sortOptions = [
    'popularity.desc' => 'Popularity desc',
    'popularity.asc' => 'Popularity asc',
    'vote_average.desc' => 'Rating desc',
    'vote_average.asc' => 'Rating asc',
    'release_date.desc' => 'Newest movies',
    'first_air_date.desc' => 'Newest shows',
];
$genreOptions = $genres ?? [];
$languageOptions = $languageOptions ?? [];
$countryOptions = $countryOptions ?? [];
$stats = $importerStats ?? ['credits' => 'TMDB', 'used' => 0, 'requests' => 'Live'];
$filters = $filters ?? [];
?>

<div class="importer-container">
    <div class="importer-tabs">
        <button type="button" id="dbmvstabapp-movie" class="importer-tab <?= $activeTab === 'movies' ? 'active' : '' ?>" data-type="movies">
            <i class="icon-movie"></i> Movies
        </button>
        <button type="button" id="dbmvstabapp-tv" class="importer-tab <?= $activeTab === 'tv' ? 'active' : '' ?>" data-type="tv">
            <i class="icon-live_tv"></i> TV Shows
        </button>
        <div class="importer-stats">
            <span><strong><?= escape((string) $stats['credits']) ?></strong> Credits</span>
            <span><strong><?= number_format((int) $stats['used']) ?></strong> Used</span>
            <span><strong><?= escape((string) $stats['requests']) ?></strong> Requests</span>
        </div>
    </div>

    <div class="importer-toolbar">
        <form action="/admin/importer" method="GET" id="dbmovies-form-filter" class="importer-filter">
            <input type="hidden" name="tab" value="<?= escape($activeTab) ?>">
            <input type="hidden" name="q" value="<?= escape($query ?? '') ?>">
            
            <input type="number" id="dbmvs-year" name="year" min="1900" max="<?= date('Y') + 1 ?>" value="<?= escape((string) ($year ?? '')) ?>" placeholder="Year">
            
            <select id="dbmvs-popularity" name="sort">
                <?php foreach ($sortOptions as $value => $label): ?>
                    <option value="<?= escape($value) ?>" <?= ($sort ?? '') === $value ? 'selected' : '' ?>><?= escape($label) ?></option>
                <?php endforeach; ?>
            </select>
            
            <select id="dbmvs-genre" name="genre">
                <option value="">All genres</option>
                <?php foreach ($genreOptions as $genreOption): ?>
                    <option value="<?= (int) $genreOption['id'] ?>" <?= (int) ($genre ?? 0) === (int) $genreOption['id'] ? 'selected' : '' ?>>
                        <?= escape((string) $genreOption['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            
            <select id="dbmvs-language" name="language">
                <option value="">All languages</option>
                <?php foreach ($languageOptions as $value => $label): ?>
                    <option value="<?= escape($value) ?>" <?= ($language ?? '') === $value ? 'selected' : '' ?>><?= escape($label) ?></option>
                <?php endforeach; ?>
            </select>
            
            <select id="dbmvs-country" name="country">
                <option value="">All countries</option>
                <?php foreach ($countryOptions as $value => $label): ?>
                    <option value="<?= escape($value) ?>" <?= ($country ?? '') === $value ? 'selected' : '' ?>><?= escape($label) ?></option>
                <?php endforeach; ?>
            </select>

            <div class="importer-advanced-filters">
                <label>
                    <span>Adult</span>
                    <select name="include_adult">
                        <option value="0" <?= empty($filters['include_adult']) ? 'selected' : '' ?>>False</option>
                        <option value="1" <?= !empty($filters['include_adult']) ? 'selected' : '' ?>>True</option>
                    </select>
                </label>
                <label class="movie-only-control">
                    <span>Video</span>
                    <select name="include_video">
                        <option value="0" <?= empty($filters['include_video']) ? 'selected' : '' ?>>False</option>
                        <option value="1" <?= !empty($filters['include_video']) ? 'selected' : '' ?>>True</option>
                    </select>
                </label>
                <label>
                    <span>Rating min</span>
                    <input type="number" name="vote_average_gte" min="0" max="10" step="0.1" value="<?= escape((string) ($filters['vote_average_gte'] ?? '')) ?>">
                </label>
                <label>
                    <span>Rating max</span>
                    <input type="number" name="vote_average_lte" min="0" max="10" step="0.1" value="<?= escape((string) ($filters['vote_average_lte'] ?? '')) ?>">
                </label>
                <label>
                    <span>Votes min</span>
                    <input type="number" name="vote_count_gte" min="0" step="1" value="<?= escape((string) ($filters['vote_count_gte'] ?? '')) ?>">
                </label>
                <label>
                    <span>Votes max</span>
                    <input type="number" name="vote_count_lte" min="0" step="1" value="<?= escape((string) ($filters['vote_count_lte'] ?? '')) ?>">
                </label>
                <label>
                    <span>Date from</span>
                    <input type="date" name="date_gte" value="<?= escape((string) ($filters['date_gte'] ?? '')) ?>">
                </label>
                <label>
                    <span>Date to</span>
                    <input type="date" name="date_lte" value="<?= escape((string) ($filters['date_lte'] ?? '')) ?>">
                </label>
                <label class="movie-only-control">
                    <span>Primary from</span>
                    <input type="date" name="primary_date_gte" value="<?= escape((string) ($filters['primary_date_gte'] ?? '')) ?>">
                </label>
                <label class="movie-only-control">
                    <span>Primary to</span>
                    <input type="date" name="primary_date_lte" value="<?= escape((string) ($filters['primary_date_lte'] ?? '')) ?>">
                </label>
                <label>
                    <span>Region</span>
                    <input type="text" name="region" maxlength="2" value="<?= escape((string) ($filters['region'] ?? '')) ?>" placeholder="US">
                </label>
                <label>
                    <span>Watch region</span>
                    <input type="text" name="watch_region" maxlength="2" value="<?= escape((string) ($filters['watch_region'] ?? '')) ?>" placeholder="US">
                </label>
                <label>
                    <span>Network</span>
                    <select id="dbmvs-network" name="network" size="5" class="custom-select" style="max-height: 11rem; overflow-y: auto;">
                        <option value="">All networks</option>
                        <?php foreach ($networkOptions ?? [] as $networkOption): ?>
                            <option value="<?= (int) $networkOption['id'] ?>" <?= (string) ($filters['network'] ?? '') === (string) ((int) $networkOption['id']) ? 'selected' : '' ?>>
                                <?= escape((string) $networkOption['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </div>
            
            <button type="submit" id="dbmvs-btn-filter" class="paper-btn primary">
                <i class="icon-search"></i> Discover
            </button>
        </form>

        <form action="/admin/importer" method="GET" id="dbmovies-form-search" class="importer-search">
            <input type="hidden" name="tab" value="<?= escape($activeTab) ?>">
            <input type="text" id="dbmvs-search-term" name="q" value="<?= escape($query ?? '') ?>" placeholder="Search for content..">
            <button type="submit" id="dbmvs-btn-search" class="paper-btn primary">
                <i class="icon-search"></i>
            </button>
        </form>

        <form id="dbmovies-hydrate-form" class="importer-hydrate">
            <input type="hidden" name="token" value="<?= escape((string) ($_csrfToken ?? '')) ?>">
            <label for="dbmvs-hydrate-scope" class="sr-only">Hydrate scope</label>
            <select id="dbmvs-hydrate-scope" name="scope" class="custom-select" aria-label="Hydrate scope">
                <option value="all">Hydrate all</option>
                <option value="items">Items only</option>
                <option value="seasons">Seasons only</option>
                <option value="episodes">Episodes only</option>
            </select>
            <label for="dbmvs-hydrate-limit" class="sr-only">Batch size</label>
            <input id="dbmvs-hydrate-limit" name="limit" type="number" min="1" max="200" value="50" aria-label="Hydrate batch size">
            <button type="submit" id="dbmvs-btn-hydrate" class="paper-btn">
                <i class="icon-image"></i> Sync TMDB Image URLs
            </button>
        </form>

        <form id="dbmovies-generate-missing-form" class="importer-generate-missing">
            <input type="hidden" name="token" value="<?= escape((string) ($_csrfToken ?? '')) ?>">
            <label for="dbmvs-generate-limit" class="sr-only">Shows per run</label>
            <input id="dbmvs-generate-limit" name="limit" type="number" min="1" max="100" value="10" aria-label="TV shows per run">
            <button type="submit" id="dbmvs-btn-generate-missing" class="paper-btn primary">
                <i class="icon-auto_fix_high"></i> Generate Missing Seasons & Episodes
            </button>
        </form>
    </div>

    <div class="importer-logs">
        <div id="dbmovies-logs-box">
            <span class="log-entry log-success"><i class="icon-check"></i> Welcome, the service has started successfully</span>
        </div>
    </div>

    <div id="importerMeta" class="importer-meta">
        <span id="dbmvs-total-results">Loading TMDB results...</span>
        <span id="dbmvs-current-page">Page 1</span>
    </div>

    <div class="importer-bulk-actions">
        <button type="button" id="importVisible" class="paper-btn primary" disabled>
            <i class="icon-cloud_download"></i> Import All Displayed
        </button>
    </div>

    <div id="importerGrid" class="importer-grid">
        <div class="importer-empty">
            <i class="icon-cloud_download"></i>
            <strong>Loading importer</strong>
            <span>Fetching fresh TMDB metadata without reloading the page.</span>
        </div>
    </div>

    <div class="importer-pagination">
        <button type="button" id="importPrev" class="paper-btn">
            <i class="icon-chevron_left"></i> Previous
        </button>
        <span class="pagination-info">
            <span id="dbmvs-page-display">Page 1</span>
        </span>
        <button type="button" id="importNext" class="paper-btn primary">
            Load More <i class="icon-chevron_right"></i>
        </button>
    </div>
</div>

<?= $this->end() ?>

<?= $this->start('scripts') ?>
<script>
(() => {
    const state = {
        tab: <?= json_encode($activeTab) ?>,
        page: 1,
        q: <?= json_encode((string) ($query ?? '')) ?>,
        year: <?= json_encode((string) ($year ?? '')) ?>,
        sort: <?= json_encode((string) ($sort ?? 'popularity.desc')) ?>,
        genre: <?= json_encode((string) ($genre ?? '')) ?>,
        language: <?= json_encode((string) ($language ?? '')) ?>,
        country: <?= json_encode((string) ($country ?? '')) ?>,
        include_adult: <?= json_encode(!empty($filters['include_adult']) ? '1' : '0') ?>,
        include_video: <?= json_encode(!empty($filters['include_video']) ? '1' : '0') ?>,
        vote_average_gte: <?= json_encode((string) ($filters['vote_average_gte'] ?? '')) ?>,
        vote_average_lte: <?= json_encode((string) ($filters['vote_average_lte'] ?? '')) ?>,
        vote_count_gte: <?= json_encode((string) ($filters['vote_count_gte'] ?? '')) ?>,
        vote_count_lte: <?= json_encode((string) ($filters['vote_count_lte'] ?? '')) ?>,
        date_gte: <?= json_encode((string) ($filters['date_gte'] ?? '')) ?>,
        date_lte: <?= json_encode((string) ($filters['date_lte'] ?? '')) ?>,
        primary_date_gte: <?= json_encode((string) ($filters['primary_date_gte'] ?? '')) ?>,
        primary_date_lte: <?= json_encode((string) ($filters['primary_date_lte'] ?? '')) ?>,
        region: <?= json_encode((string) ($filters['region'] ?? '')) ?>,
        watch_region: <?= json_encode((string) ($filters['watch_region'] ?? '')) ?>,
        network: <?= json_encode((string) ($filters['network'] ?? '')) ?>,
        totalPages: 1,
        nextPage: null,
        token: <?= json_encode((string) ($_csrfToken ?? '')) ?>,
    };
    const genresByTab = <?= json_encode($genresByTab ?? ['movies' => [], 'tv' => []]) ?>;

    const grid = document.getElementById('importerGrid');
    const meta = document.getElementById('importerMeta');
    const form = document.querySelector('.importer-filter');
    const searchForm = document.querySelector('.importer-search');
    const prev = document.getElementById('importPrev');
    const next = document.getElementById('importNext');
    const genreField = document.getElementById('dbmvs-genre');
    const hydrateForm = document.getElementById('dbmovies-hydrate-form');
    const generateMissingForm = document.getElementById('dbmovies-generate-missing-form');
    const importVisible = document.getElementById('importVisible');

    const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;',
    }[char]));

    const empty = (icon, title, message) => {
        grid.innerHTML = `<div class="importer-empty"><i class="${icon}"></i><strong>${esc(title)}</strong><span>${esc(message)}</span></div>`;
    };

    const queryString = () => new URLSearchParams({
        tab: state.tab,
        page: String(state.page),
        q: state.q,
        year: state.year,
        sort: state.sort,
        genre: state.genre,
        language: state.language,
        country: state.country,
        include_adult: state.include_adult,
        include_video: state.include_video,
        vote_average_gte: state.vote_average_gte,
        vote_average_lte: state.vote_average_lte,
        vote_count_gte: state.vote_count_gte,
        vote_count_lte: state.vote_count_lte,
        date_gte: state.date_gte,
        date_lte: state.date_lte,
        primary_date_gte: state.primary_date_gte,
        primary_date_lte: state.primary_date_lte,
        region: state.region,
        watch_region: state.watch_region,
        network: state.network,
    });

    const filterKeys = [
        'include_adult',
        'include_video',
        'vote_average_gte',
        'vote_average_lte',
        'vote_count_gte',
        'vote_count_lte',
        'date_gte',
        'date_lte',
        'primary_date_gte',
        'primary_date_lte',
        'region',
        'watch_region',
        'network',
    ];

    const syncStateFromFilterForm = () => {
        state.year = form.year.value.trim();
        state.sort = form.sort.value;
        state.genre = form.genre.value;
        state.language = form.language.value;
        state.country = form.country.value;
        filterKeys.forEach((key) => {
            const field = form.elements[key];
            state[key] = field ? String(field.value || '').trim() : '';
        });
    };

    const renderFilterHiddenInputs = () => filterKeys.map((key) => (
        `<input type="hidden" name="${esc(key)}" value="${esc(state[key] || '')}">`
    )).join('');

    const syncMovieOnlyControls = () => {
        document.querySelectorAll('.movie-only-control').forEach((field) => {
            field.classList.toggle('is-muted', state.tab !== 'movies');
        });
    };

    const skeletonGrid = () => {
        const count = 12;
        grid.innerHTML = Array.from({length: count}, () =>
            `<div class="sk-card"></div>`
        ).join('');
        grid.className = 'importer-grid sk-grid';
    };

    const setBusy = (busy) => {
        if (busy) {
            skeletonGrid();
        } else {
            grid.className = 'importer-grid';
        }
        form.querySelectorAll('button, input, select').forEach((field) => field.disabled = busy);
        prev.disabled = busy || state.page <= 1;
        next.disabled = busy || !state.nextPage;
        importVisible.disabled = busy || !grid.querySelector('[data-import-form]');
    };

    const renderMeta = (data) => {
        const total = Number(data.meta?.total_results ?? 0).toLocaleString();
        const visible = Number(data.meta?.visible_results ?? 0).toLocaleString();
        state.totalPages = Number(data.meta?.total_pages ?? 1);
        state.page = Number(data.meta?.page ?? state.page);
        state.nextPage = data.meta?.next_page ? Number(data.meta.next_page) : null;
        const scanned = Number(data.meta?.scanned_pages ?? 1);
        const scanLabel = scanned > 1 ? ` · scanned ${scanned} pages` : '';
        meta.innerHTML = `<span>${visible} visible from ${total} TMDB results${scanLabel}</span><span>Page ${state.page.toLocaleString()} of ${state.totalPages.toLocaleString()}</span>`;
        document.getElementById('dbmvs-page-display').textContent = `Page ${state.page}`;
        prev.disabled = state.page <= 1;
        next.disabled = !state.nextPage;
    };

    const renderGenres = () => {
        const current = state.genre;
        const items = genresByTab[state.tab] || [];
        genreField.innerHTML = '<option value="">All genres</option>' + items.map((item) => {
            const id = String(item.id || '');
            return `<option value="${esc(id)}" ${id === current ? 'selected' : ''}>${esc(item.name || '')}</option>`;
        }).join('');

        if (!items.some((item) => String(item.id || '') === current)) {
            state.genre = '';
            genreField.value = '';
        }
    };

    const isReleasedByToday = (item) => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        // Get the release date - the API returns it as 'date' field
        const releaseDate = item.date;
        
        // If no date available, return false
        if (!releaseDate) {
            return false;
        }
        
        const itemDate = new Date(releaseDate);
        itemDate.setHours(0, 0, 0, 0);
        
        // Check if date is valid and not in the future
        if (isNaN(itemDate.getTime())) {
            return false;
        }
        
        return itemDate <= today;
    };

    const card = (item) => {
        return `
            <article class="import-card" data-tmdb-id="${item.id}">
                <div class="import-poster">
                    ${item.poster_url ? `<img src="${esc(item.poster_url)}" alt="">` : '<i class="icon-image"></i>'}
                    <span class="rating"><i class="icon-star"></i>${esc(item.vote_average)}</span>
                </div>
                <div class="import-card-body">
                    <strong title="${esc(item.title)}">${esc(item.title)}</strong>
                    <span>${esc(item.year)} &middot; ${esc(item.language || 'N/A')} &middot; ${Number(item.vote_count || 0).toLocaleString()} votes</span>
                </div>
                <form class="import-action" data-import-form>
                    <input type="hidden" name="token" value="${esc(state.token)}">
                    <input type="hidden" name="tab" value="${esc(state.tab)}">
                    <input type="hidden" name="tmdb_id" value="${item.id}">
                    ${renderFilterHiddenInputs()}
                    <label class="import-featured-toggle">
                        <input type="checkbox" name="featured" value="1">
                        <span>Featured</span>
                    </label>
                    <button class="paper-btn primary" type="submit" style="width: 100%; justify-content: center;"><i class="icon-cloud_download"></i>Import</button>
                </form>
            </article>
        `;
    };

    // Serial import queue — ensures each import uses the fresh CSRF token
    // returned by the previous one, preventing concurrent token mismatch (419).
    let importQueue = Promise.resolve();

    const runImport = (importForm) => {
        const button = importForm.querySelector('button');
        const original = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '<i class="icon-hourglass_top"></i>Importing...';

        // Sync the hidden token field with the latest known token before sending.
        const tokenField = importForm.querySelector('[name="token"]');
        if (tokenField) tokenField.value = state.token;
        const payload = new FormData(importForm);
        const featuredField = importForm.querySelector('[name="featured"]');
        if (featuredField?.checked) {
            payload.set('featured', '1');
        } else {
            payload.delete('featured');
        }

        return fetch('/admin/importer/import', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'},
            body: new URLSearchParams(payload),
        })
        .then((response) => response.json().then((data) => ({ response, data })))
        .then(({ response, data }) => {
            const freshToken = data.csrf_token || data.error?.csrf_token;
            if (freshToken) {
                state.token = freshToken;
                document.querySelectorAll('[name="token"]').forEach((field) => {
                    field.value = freshToken;
                });
            }

            if (!response.ok || !data.ok) {
                throw new Error(data.error?.message || 'Import failed.');
            }

            importForm.closest('.import-card')?.remove();
            importVisible.disabled = !grid.querySelector('[data-import-form]');
            if (!grid.querySelector('.import-card')) {
                empty('icon-check', 'Imported all visible items', 'Fetch the next page or adjust your filters.');
                importVisible.disabled = true;
            }
        })
        .catch((error) => {
            alert(error.message);
            button.disabled = false;
            button.innerHTML = original;
        });
    };

    const bindImports = () => {
        grid.querySelectorAll('[data-import-form]').forEach((importForm) => {
            importForm.addEventListener('submit', (event) => {
                event.preventDefault();
                // Chain onto the queue so imports run one at a time.
                importQueue = importQueue.then(() => runImport(importForm));
            });
        });
        importVisible.disabled = !grid.querySelector('[data-import-form]');
    };

    const importDisplayed = () => {
        const forms = Array.from(grid.querySelectorAll('[data-import-form]'));
        if (!forms.length) {
            return;
        }

        const original = importVisible.innerHTML;
        importVisible.disabled = true;
        importVisible.innerHTML = '<i class="icon-hourglass_top"></i>Importing displayed...';

        importQueue = importQueue
            .then(() => forms.reduce((chain, importForm) => (
                chain.then(() => document.body.contains(importForm) ? runImport(importForm) : Promise.resolve())
            ), Promise.resolve()))
            .finally(() => {
                importVisible.innerHTML = original;
                importVisible.disabled = !grid.querySelector('[data-import-form]');
            });
    };

    const runHydration = (formEl) => {
        const button = formEl.querySelector('#dbmvs-btn-hydrate');
        const original = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '<i class="icon-hourglass_top"></i>Hydrating...';
        formEl.querySelector('[name="token"]').value = state.token;

        return fetch('/admin/importer/hydrate-images', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'},
            body: new URLSearchParams(new FormData(formEl)),
        })
        .then((response) => response.json().then((data) => ({ response, data })))
        .then(({ response, data }) => {
            const freshToken = data.csrf_token || data.error?.csrf_token;
            if (freshToken) {
                state.token = freshToken;
                document.querySelectorAll('[name="token"]').forEach((field) => {
                    field.value = freshToken;
                });
            }

            if (!response.ok || !data.ok) {
                throw new Error(data.error?.message || 'Hydration failed.');
            }

            alert(data.message || 'Hydration finished.');
        })
        .catch((error) => {
            alert(error.message);
        })
        .finally(() => {
            button.disabled = false;
            button.innerHTML = original;
        });
    };

    const runGenerateMissing = (formEl) => {
        const button = formEl.querySelector('#dbmvs-btn-generate-missing');
        const original = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '<i class="icon-hourglass_top"></i>Generating...';
        formEl.querySelector('[name="token"]').value = state.token;

        return fetch('/admin/importer/generate-missing-tv', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'},
            body: new URLSearchParams(new FormData(formEl)),
        })
        .then((response) => response.json().then((data) => ({ response, data })))
        .then(({ response, data }) => {
            const freshToken = data.csrf_token || data.error?.csrf_token;
            if (freshToken) {
                state.token = freshToken;
                document.querySelectorAll('[name="token"]').forEach((field) => {
                    field.value = freshToken;
                });
            }

            if (!response.ok || !data.ok) {
                throw new Error(data.error?.message || 'Generate missing failed.');
            }

            const summary = data.summary || {};
            const errors = Array.isArray(summary.errors) ? summary.errors : [];
            const suffix = errors.length ? `\n\nErrors (${errors.length}):\n- ` + errors.slice(0, 5).join('\n- ') : '';
            alert((data.message || 'Generation completed.') + suffix);
        })
        .catch((error) => {
            alert(error.message);
        })
        .finally(() => {
            button.disabled = false;
            button.innerHTML = original;
        });
    };

    const load = async () => {
        setBusy(true);

        try {
            const response = await fetch('/admin/importer/results?' + queryString().toString(), {
                headers: {'Accept': 'application/json'},
            });
            const data = await response.json();

            if (!response.ok || !data.ok) {
                throw new Error(data.error?.message || 'Could not load TMDB results.');
            }

            renderMeta(data);
            const releasedItems = data.results.filter(isReleasedByToday);
            
            // Sort by release date descending (newest first, going backwards)
            releasedItems.sort((a, b) => {
                const dateA = a.date;
                const dateB = b.date;
                return new Date(dateB) - new Date(dateA);
            });
            
            grid.innerHTML = releasedItems.length
                ? releasedItems.map(card).join('')
                : '<div class="importer-empty"><i class="icon-search"></i><strong>No released content found</strong><span>Items displayed are only those released today or earlier. Try a different page or adjust your filters.</span></div>';
            grid.className = 'importer-grid';
            bindImports();
            importVisible.disabled = releasedItems.length === 0;
        } catch (error) {
            meta.innerHTML = '<span>TMDB connection issue</span><span>Page ' + state.page + '</span>';
            empty('icon-cloud_off', 'TMDB is not connected yet', error.message);
            importVisible.disabled = true;
        } finally {
            setBusy(false);
        }
    };

    form.addEventListener('submit', (event) => {
        event.preventDefault();
        state.page = 1;
        state.nextPage = null;
        state.q = form.q.value.trim();
        syncStateFromFilterForm();
        searchForm.q.value = '';
        state.q = '';
        load();
    });

    searchForm.addEventListener('submit', (event) => {
        event.preventDefault();
        state.page = 1;
        state.nextPage = null;
        state.q = searchForm.q.value.trim();
        syncStateFromFilterForm();
        form.q.value = state.q;
        load();
    });

    document.querySelectorAll('.importer-tab').forEach((tab) => {
        tab.addEventListener('click', (event) => {
            const newTab = tab.getAttribute('data-type');
            if (newTab && newTab !== state.tab) {
                state.tab = newTab;
                state.page = 1;
                state.nextPage = null;
                state.genre = '';
                state.language = '';
                state.country = '';
                form.tab.value = state.tab;
                searchForm.tab.value = state.tab;
                form.language.value = '';
                form.country.value = '';
                syncMovieOnlyControls();
                renderGenres();
                document.querySelectorAll('.importer-tab').forEach((link) => {
                    link.classList.toggle('active', link === tab);
                });
                history.replaceState(null, '', '/admin/importer?tab=' + encodeURIComponent(state.tab));
                load();
            }
        });
    });

    prev.addEventListener('click', () => {
        if (state.page > 1) {
            state.page -= 1;
            load();
        }
    });

    next.addEventListener('click', () => {
        if (state.nextPage) {
            state.page = state.nextPage;
            load();
        }
    });

    importVisible.addEventListener('click', importDisplayed);

    hydrateForm?.addEventListener('submit', (event) => {
        event.preventDefault();
        importQueue = importQueue.then(() => runHydration(hydrateForm));
    });

    generateMissingForm?.addEventListener('submit', (event) => {
        event.preventDefault();
        importQueue = importQueue.then(() => runGenerateMissing(generateMissingForm));
    });

    renderGenres();
    syncMovieOnlyControls();
    load();
})();
</script>
<?= $this->end() ?>
